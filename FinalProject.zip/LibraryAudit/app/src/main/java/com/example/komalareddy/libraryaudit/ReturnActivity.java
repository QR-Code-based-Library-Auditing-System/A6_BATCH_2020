package com.example.komalareddy.libraryaudit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ReturnActivity extends AppCompatActivity {

    FirebaseDatabase mdatabase;
    DatabaseReference mReference;
    EditText editText;
    String str12;
    Button b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_return);
        editText = findViewById(R.id.bookacno);
        b2 = findViewById(R.id.returnbook);
        mdatabase = FirebaseDatabase.getInstance();
        mReference = mdatabase.getReference();

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str12 = editText.getText().toString();
                mReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        long num = dataSnapshot.getChildrenCount();
                        for (int i = 0; i < num; i++) {
                            String str = String.valueOf(i);
                            String acno = dataSnapshot.child(str).child("AccNo").getValue().toString();
                            if (str12.equals(acno)) {
                                mReference.child(str).child("Issued").setValue("");
                                Toast.makeText(ReturnActivity.this, "Return Successful", Toast.LENGTH_SHORT).show();
                                break;
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(ReturnActivity.this, "null", Toast.LENGTH_SHORT).show();

                    }
                });
            }
        });
    }
}
