package com.example.komalareddy.libraryaudit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DepartmentActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    Spinner sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);
        sp=findViewById(R.id.spinner);
        mAuth = FirebaseAuth.getInstance();
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String dept=sp.getItemAtPosition(position).toString();
                if (!dept.equals("CSE")){
                    Toast.makeText(DepartmentActivity.this, "Please select CSE", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void proceed(View view) {
        Intent inte=new Intent(DepartmentActivity.this,LoginActivity.class);
        startActivity(inte);
    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null){
            String useremail=currentUser.getEmail();
            if (useremail.equals("admin@gmail.com")) {
                Intent intent = new Intent(this, IssueAndReportActivity.class);
                startActivity(intent);
            }else {
                Intent inten = new Intent(this, ScanActivity.class);
                startActivity(inten);
            }
        }
    }
}
