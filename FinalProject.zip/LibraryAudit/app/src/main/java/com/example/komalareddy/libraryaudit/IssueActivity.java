package com.example.komalareddy.libraryaudit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class IssueActivity extends AppCompatActivity {

    FirebaseDatabase mdatabase;
    DatabaseReference mReference;
    EditText et, et2;
    String str1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_issue);
        et = findViewById(R.id.acno);
        et2 = findViewById(R.id.editText);
        b1 = findViewById(R.id.button);
        mdatabase = FirebaseDatabase.getInstance();
        mReference = mdatabase.getReference();
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(TextUtils.isEmpty(et.getText().toString())) && !(TextUtils.isEmpty(et2.getText().toString()))) {
                    b1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //str1 = et.getText().toString();
                            mReference.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    long num = dataSnapshot.getChildrenCount();
                                    for (int i = 0; i < num; i++) {
                                        String str = String.valueOf(i);
                                        String acno = dataSnapshot.child(str).child("AccNo").getValue().toString();
                                        String issue = dataSnapshot.child(str).child("Issued").getValue().toString();
                                        if ((et.getText().toString()).equals(acno)) {
                                            if (!(issue.equals(""))) {
                                                Toast.makeText(IssueActivity.this, "Already Issued to " + issue, Toast.LENGTH_SHORT).show();
                                            } else {
                                                mReference.child(str).child("Issued").setValue(et2.getText().toString());
                                                Toast.makeText(IssueActivity.this, "Issued to " + et2.getText().toString(), Toast.LENGTH_SHORT).show();
                                            }
                                            break;
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    Toast.makeText(IssueActivity.this, "null", Toast.LENGTH_SHORT).show();

                                }
                            });
                        }
                    });
                }else {
                    Toast.makeText(IssueActivity.this, "Please enter Book No.& Emp ID", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
