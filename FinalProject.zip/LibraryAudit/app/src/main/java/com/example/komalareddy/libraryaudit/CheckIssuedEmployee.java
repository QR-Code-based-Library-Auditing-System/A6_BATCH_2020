package com.example.komalareddy.libraryaudit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CheckIssuedEmployee extends AppCompatActivity {

    EditText editText;
    TextView textView;
    String string;
    ListView datas;
    ArrayList<String> strings;
    FirebaseDatabase mDatabase;
    DatabaseReference mReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_issued_employee);
        editText=findViewById(R.id.employeeid);
        textView=findViewById(R.id.result1);
        datas=findViewById(R.id.listView);
        strings=new ArrayList<>();
        mDatabase=FirebaseDatabase.getInstance();
        mReference=mDatabase.getReference();
    }
    public void submit1(View view) {
        string=editText.getText().toString();
        mReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                long num = dataSnapshot.getChildrenCount();
                for (int i = 0; i < num; i++) {
                    String str = String.valueOf(i);
                    String acno = dataSnapshot.child(str).child("AccNo").getValue().toString();
                    String issue = dataSnapshot.child(str).child("Issued").getValue().toString();
                    if (string.equals(issue)){
                        strings.add(acno);
                        textView.setText(issue+" is issued to the employee(s) with Id(s) :");
                    }
                }
                datas.setAdapter(new ArrayAdapter<String>(CheckIssuedEmployee.this,android.R.layout.simple_list_item_1,strings));
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(CheckIssuedEmployee.this, "null", Toast.LENGTH_SHORT).show();
            }
        });
   }
}
